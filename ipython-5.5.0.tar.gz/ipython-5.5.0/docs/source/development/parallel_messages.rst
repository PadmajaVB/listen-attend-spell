:orphan:

================================
Messaging for Parallel Computing
================================

IPython parallel has moved to ipyparallel -
see :ref:`ipyparallel:parallel_messages` for the documentation.
